import React from "react";

const Todolist = (props)=>{

  


    return(
        <>
            <div className="todo_style">
            <button className="but2" 
            onClick={()=>{
                props.onSelect(props.id)
            }}>
            ⚔️ </button>
            <li> {props.text}</li>

            </div>
        </>
      
    )
};



export default Todolist;