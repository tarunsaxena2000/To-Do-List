import React, { useState } from "react";
import  "./index.css";
import Todolist from "./Todolist";


const  App=()=>{

 const [inputList,setInputList] = useState("")
 const [items,setItems] =useState([]);


const itemEvent =(event)=>{
setInputList(event.target.value)
};

const listofitem =(event)=>{
   setItems((olditems)=>{
       return[...olditems,inputList];
   });
   setInputList("")
}

const deleteItems =(id)=>{
    console.log("deleted")

    setItems((olditems)=>{
        return olditems.filter((arrElem,index)=>{
            return index!==id;
        })
    })

   }


return(
    <>
<div className="main_div">

<div className="center_div">

<br></br>

<h1 className="hed">TO DO LIST</h1>
<br></br>

<input  
type="text"
 placeholder="Add a Items "
 className="tex"
 onChange={itemEvent}
 value={inputList}
 >
 
 </input> 


<button className="but" onClick={listofitem}>➕</button>



<ul>
   

{items.map((itemval,index)=>{
    return <Todolist key={index}
     id= {index}
     text ={itemval} 
     onSelect={deleteItems} />;
})}

</ul>
</div>

</div>
    </>
)};


export default App;
